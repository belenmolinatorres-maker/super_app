# AGENTS.md — Súper App Multiapp

## Stack

- **Frontend**: Vanilla HTML + JS + Tailwind CSS (CDN) + Font Awesome + Google Fonts (Inter)
- **Backend**: n8n webhooks — no custom server, no npm, no build step
- **Database**: MySQL 8.0 remote, accessed via MCP (`@toolbox-sdk/server --prebuilt=mysql`)
- **Production URL**: `https://ideasypruebas2.es/cursos/IFCT0211/Belen/` (Managed via n8n and MySQL)

## Critical SQL rules (never violate)

1. **No `DELETE`** — use logical deletion: `UPDATE ... SET fecha_eliminacion = NOW(), usuario_eliminacion = <id>`
2. **Passwords are `VARBINARY(255)`** — always use `encriptar('...')` / `encriptar_pass_miniapp(...)` in queries, never store/compare plaintext
3. **Multi-tenant isolation** — every `app` query must include `WHERE app.usuario = <id_usuario_session>`
4. **Active records** — always filter `WHERE fecha_eliminacion IS NULL`

## API (n8n webhooks)

Base: `https://n8n.misappsfantasticas.cloud/webhook/` (use `/webhook-test/` for testing)

| Endpoint | Method | Purpose |
|---|---|---|
| `login` | POST | Auth, returns JWT |
| `login/forgot` | POST | Password recovery request |
| `logout` / `logoult` | POST | Session teardown |
| `listar_app` | POST | User's mini-apps |
| `crud_app` | POST | Create/Edit/Delete apps (field: `funcion`) |
| `listar_catalogo` | POST | Master catalog |
| `alta_catologo` | POST | Admin: create catalog entry |
| `admin` | POST | Admin permission check |
| `recuperar_contraseya` | POST | Forgot-password trigger |
| `resetear` | POST | Reset password |
| `verificar_acceso` | POST | Verifica credenciales antes de abrir una app |

## Access gate (verificar_acceso)

- When clicking an app card, a modal asks for the stored password
- Frontend POSTs to `/webhook/verificar_acceso` with `{ token, id_app, contraseya }`
- n8n compares `contraseya` against `app.contraseya` (hashed) in MySQL
- Returns `{ codigo: 1 }` on success → frontend opens the app URL in new tab
- Returns `{ codigo: 0, mensaje: "..." }` on failure

## Auth & session

- Login response stores JWT in `localStorage` under **both** `jwt_token` and `token` keys
- Dashboard/Admin JS reads: `localStorage.getItem('token') || localStorage.getItem('jwt_token')`
- User display name stored in `localStorage` key `usuario_nombre`
- Protected pages redirect to `../index.html` if no token found
- Logout flow: POST to `/webhook/logoult`, clear localStorage, redirect

## File tree

```
/
├── index.html                     # Login (public)
├── reset_password.html            # Password reset page
├── assets/js/auth.js              # Login + forgot-password modal
├── assets/js/dashboard.js         # User dashboard (mini-apps CRUD)
├── assets/js/admin.js             # Admin panel (catalog management)
├── assets/js/reset.js             # Reset password logic
├── private/dashboard.html         # Authenticated dashboard shell
├── private/admin.html             # Admin panel shell
├── bd/esquema.md                  # DB schema (tables: usuario, catalogo, app)
├── plantillas/recuperacion_password.html  # Email template (n8n `{{ $json.var }}` syntax)
└── .gemini/settings.json          # MCP connection to MySQL
```

## Email template note

`plantillas/recuperacion_password.html` uses n8n variable syntax: `{{ $json.nombre }}`, `{{ $json.usuario }}`, `{{ $json.id_usuario }}`. The recovery link points to `https://n8n.misappsfantasticas.cloud/webhook/reset-page?id={{ $json.id_usuario }}` (n8n devuelve el HTML directamente, hosteado en `plantillas/n8n_reset_page.html`).

## MCP (DB access)

Configured in `.gemini/settings.json`. Connect to MySQL with: `npx -y @toolbox-sdk/server --prebuilt=mysql --stdio` with env vars from that file. DB: `app_multiapp`.

## Admin panel

Only accessible after passing admin check: POST to `/webhook/admin` with token; response `codigo === "1"` grants access. Non-admins are redirected to `dashboard.html`. Buttons for "Crear usuario" and "Dar de baja" show a "coming soon" notification — only "Crear catálogo" is implemented.
